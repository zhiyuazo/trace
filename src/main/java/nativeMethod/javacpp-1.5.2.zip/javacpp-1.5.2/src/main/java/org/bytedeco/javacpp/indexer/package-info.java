/**
 * Contains classes for multidimensional access of arrays and buffers.
 */
@org.osgi.annotation.bundle.Export
@org.osgi.annotation.versioning.Version("1.5.0")
package org.bytedeco.javacpp.indexer;
