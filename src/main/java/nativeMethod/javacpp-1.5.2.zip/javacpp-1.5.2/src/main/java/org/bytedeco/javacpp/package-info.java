/**
 * Contains the main set of classes for JavaCPP at runtime.
 */
@org.osgi.annotation.bundle.Export
@org.osgi.annotation.versioning.Version("1.5.0")
package org.bytedeco.javacpp;
