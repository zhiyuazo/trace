/**
 * Contains classes used at build time by JavaCPP.
 */
@org.osgi.annotation.bundle.Export(
		attribute="exclude:=\"BuildMojo,ParseMojo\"")
@org.osgi.annotation.versioning.Version("1.5.0")
package org.bytedeco.javacpp.tools;
