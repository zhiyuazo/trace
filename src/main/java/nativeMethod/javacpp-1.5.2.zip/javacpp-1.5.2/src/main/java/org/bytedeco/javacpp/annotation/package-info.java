/**
 * Contains all the annotation classes used by JavaCPP.
 */
@org.osgi.annotation.bundle.Export
@org.osgi.annotation.versioning.Version("1.5.0")
package org.bytedeco.javacpp.annotation;
