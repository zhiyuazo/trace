module org.bytedeco.javacpp {
    requires jdk.unsupported;
    exports org.bytedeco.javacpp;
    exports org.bytedeco.javacpp.annotation;
    exports org.bytedeco.javacpp.indexer;
    exports org.bytedeco.javacpp.tools;
}
