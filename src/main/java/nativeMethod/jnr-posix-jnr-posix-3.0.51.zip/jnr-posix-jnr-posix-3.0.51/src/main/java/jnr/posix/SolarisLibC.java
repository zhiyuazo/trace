package jnr.posix;

public interface SolarisLibC extends UnixLibC {
}
